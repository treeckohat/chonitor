run these in terminal:
pip install pywin32
pip install cryptography

run the 
'Mora_Bank_Main.py'
file ONLY thx

other users you can test:
MugiwaraNoLuffy 8008
col3slaw 5678
poor 0000